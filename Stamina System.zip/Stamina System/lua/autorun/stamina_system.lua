--[[---------------------------------------------------------
    Stamina System for GMod
    - Sprinting drains stamina (even when jumping)
    - Resting regenerates stamina
    - If stamina <= 0, player cannot move (only look around)
    - If stamina <= 5, movement is blocked (no WASD), but looking works
    - HUD shows stamina at top of screen
    - Toggle with: stamina_enable 0 / 1
-----------------------------------------------------------]]

if SERVER then
    util.AddNetworkString("Stamina_Update")

    CreateConVar("stamina_enable", "1", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Enable or disable the stamina system")

    local staminaData = {}
    local MAX_STAMINA = 100
    local STAMINA_DRAIN = 15 -- per second
    local STAMINA_REGEN = 10 -- per second
    local LOW_STAMINA = 5

    hook.Add("PlayerInitialSpawn", "StaminaSetup", function(ply)
        staminaData[ply] = MAX_STAMINA
    end)

    hook.Add("Think", "StaminaSystem", function()
        if GetConVar("stamina_enable"):GetInt() == 0 then
            for _, ply in ipairs(player.GetAll()) do
                if ply:IsFrozen() then ply:Freeze(false) end
            end
            return
        end

        for _, ply in ipairs(player.GetAll()) do
            if not IsValid(ply) then continue end

            local stamina = staminaData[ply] or MAX_STAMINA
            local vel = ply:GetVelocity():Length2D()

            -- Sprinting drains stamina (ground or air)
            if ply:KeyDown(IN_SPEED) and vel > 50 then
                stamina = math.max(0, stamina - STAMINA_DRAIN * FrameTime())
            else
                stamina = math.min(MAX_STAMINA, stamina + STAMINA_REGEN * FrameTime())
            end

            -- If stamina <= 0, fully freeze
            if stamina <= 0 then
                ply:Freeze(true)
            else
                ply:Freeze(false)
            end

            staminaData[ply] = stamina

            net.Start("Stamina_Update")
            net.WriteFloat(stamina)
            net.Send(ply)
        end
    end)

    -- Block player movement when stamina is low (<= LOW_STAMINA)
    hook.Add("Move", "StaminaPreventMovement", function(ply, mv)
        if GetConVar("stamina_enable"):GetInt() == 0 then return end
        local stamina = staminaData[ply] or MAX_STAMINA
        if stamina <= LOW_STAMINA then
            mv:SetForwardSpeed(0)
            mv:SetSideSpeed(0)
        end
    end)

    hook.Add("PlayerDisconnected", "StaminaCleanup", function(ply)
        staminaData[ply] = nil
    end)
end

-- CLIENT
if CLIENT then
    local stamina = 100
    local MAX_STAMINA = 100

    net.Receive("Stamina_Update", function()
        stamina = net.ReadFloat()
    end)

    hook.Add("HUDPaint", "DrawStaminaBar", function()
        if GetConVar("stamina_enable"):GetInt() == 0 then return end

        local w, h = 200, 20
        local x, y = (ScrW() / 2) - (w / 2), 20 -- centered at top

        surface.SetDrawColor(50, 50, 50, 200)
        surface.DrawRect(x, y, w, h)

        local ratio = math.Clamp(stamina / MAX_STAMINA, 0, 1)
        surface.SetDrawColor(0, 200, 0, 255)
        surface.DrawRect(x, y, w * ratio, h)

        draw.SimpleText("Stamina", "DermaDefaultBold", x + w / 2, y - 15, Color(255, 255, 255), TEXT_ALIGN_CENTER)
    end)

    hook.Add("HUDShouldDraw", "HideDefaultSprint", function(name)
        if name == "CHudSuitPower" then return false end
    end)
end
